
export interface Role {
    id: number;
    name: string;
    key: string;
    status: boolean;
    permiss: string[]
}